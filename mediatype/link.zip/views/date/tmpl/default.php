<?php
/*------------------------------------------------------------------------

# TZ Portfolio Plus Extension

# ------------------------------------------------------------------------

# author    DuongTVTemPlaza

# copyright Copyright (C) 2015 templaza.com. All Rights Reserved.

# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Websites: http://www.templaza.com

# Technical Support:  Forum - http://templaza.com/Forum

-------------------------------------------------------------------------*/

// No direct access.
defined('_JEXEC') or die;

if($item   = $this -> item){
    if(isset($this -> link) && $link   = $this -> link){
$params = $this -> params;
?>

<div class="TzLink">
    <!-- Begin Icon print, Email or Edit -->
    <?php if ($params -> get('access-edit')) : ?>
        <div class="TzIcon">
            <div class="btn-group pull-right"> <a class="btn dropdown-toggle" data-toggle="dropdown" href="javascript:"> <i class="icon-cog"></i> <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li class="edit-icon"> <?php echo JHtml::_('icon.edit', $item, $params); ?> </li>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <!-- End Icon print, Email or Edit -->

    <h3 class="title">
        <i class="icon-link"></i>
        <a href="<?php echo $link -> url?>"
           rel="<?php echo $link -> follow;?>"
           target="<?php echo $link -> target?>"><?php echo $link -> title;?></a>
    </h3>
    <?php  if ($params->get('show_intro',1) AND !empty($item -> introtext)) :?>
    <div class="introtext">
        <?php echo $item -> introtext;?>
    </div>
    <?php endif; ?>
</div>
<?php } }?>