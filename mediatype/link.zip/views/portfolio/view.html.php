<?php
/*------------------------------------------------------------------------

# TZ Portfolio Plus Extension

# ------------------------------------------------------------------------

# author    DuongTVTemPlaza

# copyright Copyright (C) 2015 templaza.com. All Rights Reserved.

# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Websites: http://www.templaza.com

# Technical Support:  Forum - http://templaza.com/Forum

-------------------------------------------------------------------------*/

// No direct access.
defined('_JEXEC') or die;

class PlgTZ_Portfolio_PlusMediaTypeLinkViewPortfolio extends JViewLegacy{

    protected $item     = null;
    protected $params   = null;
    protected $link     = null;
    protected $head     = false;

    public function display($tpl = null){
        $state          = $this -> get('State');
        $params         = $state -> get('params');
        $this -> params = $params;
		$item 			= $this -> get('Item');

        if($item){
            if($media = $item -> media){
                if(isset($media -> link)){
                    $this -> link  = $media -> link;
                }
            }


            if($item  && strlen(trim($item -> introtext)) && $introLimit = $params -> get('tz_article_intro_limit')){
                $item -> introtext   = '<p>'.JHtml::_('string.truncate', $item->introtext, $introLimit, true, false).'</p>';
            }

            $this -> item   = $item;
        }

        if(!$this -> head) {
            $doc = JFactory::getDocument();
            $doc->addStyleSheet(TZ_Portfolio_PlusUri::base() . '/addons/mediatype/link/css/link.css');
            $this -> head   = true;
        }

        parent::display($tpl);
    }
}