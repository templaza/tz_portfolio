<?php
/*------------------------------------------------------------------------

# TZ Portfolio Plus Extension

# ------------------------------------------------------------------------

# author    DuongTVTemPlaza

# copyright Copyright (C) 2015 templaza.com. All Rights Reserved.

# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Websites: http://www.templaza.com

# Technical Support:  Forum - http://templaza.com/Forum

-------------------------------------------------------------------------*/

// No direct access
defined('_JEXEC') or die;

class PlgTZ_Portfolio_PlusMediaTypeModelLink extends TZ_Portfolio_PlusPluginModelAdmin
{
//    protected $data = null;
//
//
//    public function getTable($type = 'Content', $prefix = 'TZ_Portfolio_PlusTable', $config = array())
//    {
//        return JTable::getInstance($type, $prefix, $config);
//    }
//
//    public function getForm($data = array(), $loadData = true)
//    {
//        // Get the form.
//        JForm::addFormPath(__DIR__ . DIRECTORY_SEPARATOR . 'forms');
//        $form = $this->loadForm('plg_mediatype.link', 'link', array('control' => 'jform', 'load_data' => $loadData));
//        if (empty($form)) {
//            return false;
//        }
//        return $form;
//    }
//
//    protected function loadFormData()
//    {
//        // Check the session for previously entered form data.
//        $app = JFactory::getApplication();
//        $data = $app->getUserState('com_tz_portfolio_plus.edit.article.data', array());
//
//        if (empty($data)) {
//            $data = $this->getItem();
//        }
//
//        $this->preprocessData('com_tz_portfolio_plus.article', $data);
//
//        return $data;
//    }
//
//    public function getItem()
//    {
//        return $this->data;
//    }
//
//    public function setItem($data)
//    {
//        $this->data = $data;
//    }

    public function save($data){

        // Get data from form
        $link_data = JRequest::getVar('jform',array());
        $link_data = $link_data['media']['link'];

        $this -> __save($data,$link_data);
    }
}