<?php
/*------------------------------------------------------------------------
# plg_extravote - ExtraVote Plugin
# ------------------------------------------------------------------------
# author    Joomla!Vargas
# copyright Copyright (C) 2010 joomla.vargas.co.cr. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://joomla.vargas.co.cr
# Technical Support:  Forum - http://joomla.vargas.co.cr/forum
-------------------------------------------------------------------------*/

// No direct access
defined('_JEXEC') or die;
if(isset($this -> item) && $this -> item):
$params = $this -> params;
$address = $params->get('address_title');

    if(isset($address) && $address != ''):
?>
    <span class="map_title">
        <i class="fa fa-map-marker"></i>
        <?php echo $address;?>
    </span>
<?php
    endif;
endif;
