DROP TABLE IF EXISTS `#__tz_portfolio_plus_categories`
,`#__tz_portfolio_plus_addon_data`
,`#__tz_portfolio_plus_addon_meta`
,`#__tz_portfolio_plus_content`
,`#__tz_portfolio_plus_content_category_map`
,`#__tz_portfolio_plus_content_featured_map`
,`#__tz_portfolio_plus_content_rating`
,`#__tz_portfolio_plus_content_rejected`
,`#__tz_portfolio_plus_extensions`
,`#__tz_portfolio_plus_fieldgroups`
,`#__tz_portfolio_plus_fields`
,`#__tz_portfolio_plus_field_content_map`
,`#__tz_portfolio_plus_field_fieldgroup_map`
,`#__tz_portfolio_plus_tags`
,`#__tz_portfolio_plus_tag_content_map`
,`#__tz_portfolio_plus_templates`;
