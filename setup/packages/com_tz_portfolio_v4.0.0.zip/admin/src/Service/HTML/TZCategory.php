<?php
/*------------------------------------------------------------------------

# TZ Portfolio Extension

# ------------------------------------------------------------------------

# Author:    DuongTVTemPlaza

# Copyright: Copyright (C) 2011-2024 TZ Portfolio.com. All Rights Reserved.

# @License - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL

# Website: http://www.tzportfolio.com

# Technical Support:  Forum - https://www.tzportfolio.com/help/forum.html

# Family website: http://www.templaza.com

# Family Support: Forum - https://www.templaza.com/Forums.html

-------------------------------------------------------------------------*/

namespace TemPlaza\Component\TZ_Portfolio\Administrator\Service\HTML;

// no direct access
defined('_JEXEC') or die;

use Joomla\CMS\Application\CMSApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Utilities\ArrayHelper;

/**
 * Utility class for categories
 *
 * @since  1.5
 */
class TZCategory
{
    /**
     * Cached array of the category items.
     *
     * @var    array
     * @since  1.5
     */
    protected static $items = array();
    /**
     * The application
     *
     * @var    CMSApplication
     *
     * @since  __DEPLOY_VERSION__
     */
    private $application;

    public function __construct(CMSApplication $application)
    {
        $this->application = $application;
    }

    /**
     * Returns an array of categories for the given extension.
     *
     * @param   string  $extension  The extension option e.g. com_something.
     * @param   array   $config     An array of configuration options. By default, only
     *                              published and unpublished categories are returned.
     *
     * @return  array
     *
     * @since   1.5
     */
    public function options($extension, $config = array('filter.published' => array(0, 1)))
    {
        $hash = md5($extension . '.' . serialize($config));

        if (!isset(static::$items[$hash]))
        {
            $config = (array) $config;
            $db     = Factory::getDbo();
            $query  = $db->getQuery(true)
                ->select('a.id, a.title, a.level')
                ->from('#__tz_portfolio_plus_categories AS a')
                ->where('a.parent_id > 0');

            // Filter on extension.
            $query->where('extension = ' . $db->quote($extension));

            // Filter on the published state
            if (isset($config['filter.published']))
            {
                if (is_numeric($config['filter.published']))
                {
                    $query->where('a.published = ' . (int) $config['filter.published']);
                }
                elseif (is_array($config['filter.published']))
                {
                    $config['filter.published'] = ArrayHelper::toInteger($config['filter.published']);
                    $query->where('a.published IN (' . implode(',', $config['filter.published']) . ')');
                }
            }

            // Filter on the language
            if (isset($config['filter.language']))
            {
                if (is_string($config['filter.language']))
                {
                    $query->where('a.language = ' . $db->quote($config['filter.language']));
                }
                elseif (is_array($config['filter.language']))
                {
                    foreach ($config['filter.language'] as &$language)
                    {
                        $language = $db->quote($language);
                    }

                    $query->where('a.language IN (' . implode(',', $config['filter.language']) . ')');
                }
            }

            // Let's get the id for the current item, either category or content item.
            $oldCat = null;
            $jinput = Factory::getApplication()->input;

            if(isset($config['filter.parent']) && $config['filter.parent']){
                $oldCat = $jinput->get('id', 0);
                $query -> where('a.id <> '.$oldCat);
            }

            $query->order('a.lft');

            $db->setQuery($query);
            $items = $db->loadObjectList();

            // Assemble the list options.
            static::$items[$hash] = array();

            foreach ($items as &$item)
            {
                $repeat = ($item->level - 1 >= 0) ? $item->level - 1 : 0;
                $item->title = str_repeat('- ', $repeat) . $item->title;
                static::$items[$hash][] = HTMLHelper::_('select.option', $item->id, $item->title);
            }
        }

        return static::$items[$hash];
    }

    /**
     * Returns an array of categories for the given extension.
     *
     * @param   string  $extension  The extension option.
     * @param   array   $config     An array of configuration options. By default, only published and unpublished categories are returned.
     *
     * @return  array   Categories for the extension
     *
     * @since   1.6
     */
    public static function categories($extension, $config = array('filter.published' => array(0, 1)))
    {
        $hash = md5($extension . '.' . serialize($config));

        if (!isset(static::$items[$hash]))
        {
            $config = (array) $config;
//            $db     = TZ_Portfolio_PlusDatabase::getDbo();
            $db     = Factory::getDbo();
            $query  = $db->getQuery(true)
                ->select('a.id, a.title, a.level, a.parent_id')
                ->from('#__tz_portfolio_plus_categories AS a')
                ->where('a.parent_id > 0');

            // Filter on extension.
            $query->where('extension = ' . $db->quote($extension));

            // Filter on the published state
            if (isset($config['filter.published']))
            {
                if (is_numeric($config['filter.published']))
                {
                    $query->where('a.published = ' . (int) $config['filter.published']);
                }
                elseif (is_array($config['filter.published']))
                {
                    $config['filter.published'] = ArrayHelper::toInteger($config['filter.published']);
                    $query->where('a.published IN (' . implode(',', $config['filter.published']) . ')');
                }
            }

            $query->order('a.lft');

            $db->setQuery($query);
            $items = $db->loadObjectList();

            // Assemble the list options.
            static::$items[$hash] = array();

            foreach ($items as &$item)
            {
                $repeat = ($item->level - 1 >= 0) ? $item->level - 1 : 0;
                $item->title = str_repeat('- ', $repeat) . $item->title;
                static::$items[$hash][] = HTMLHelper::_('select.option', $item->id, $item->title);
            }
            // Special "Add to root" option:
            static::$items[$hash][] = HTMLHelper::_('select.option', '1', Text::_('JLIB_HTML_ADD_TO_ROOT'));
        }

        return static::$items[$hash];
    }
}
